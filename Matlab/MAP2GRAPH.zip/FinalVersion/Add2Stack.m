function Add2Stack(top,i,j,vertexnum)
global mpstack;
   mpstack(top).x=i;
   mpstack(top).y=j;
   mpstack(top).vertexnum=vertexnum;
end