function DelStack(top)
global mpstack;
mpstack(top).x=0;
mpstack(top).y=0;
mpstack(top).vertexnum=0;
end